# Tema 2 TW - Site personal

Leoca Adi-Stefan, grupa 321AA

## Ce am facut

Un site personal cu patru pagini: `home.html`, `about.html`, `portofolio.html` si `contact.html`. Am folosit doar HTML si CSS, fara JavaScript si fara biblioteci.

## Cum e organizat

- paginile HTML sunt in radacina folderului
- `css/style.css` are toate stilurile, comune pentru toate paginile
- `img/` are logo-ul si imaginile (toate in format SVG)
- `doc/` are documentul acesta

## Pagina principala

Are bara de navigare cu logo si linkuri catre celelalte pagini, apoi trei sectiuni: Educatie, Competente si Hobby. Subsolul are linkuri catre Facebook, Twitter si email si textul de copyright.

## Responsive

Sectiunile si proiectele sunt in containere `flex` cu `flex-wrap`, deci se aseaza una sub alta cand ecranul e ingust. Imaginile au `width: 100%`. Sub 600px meniul trece pe coloana (`@media`). Am verificat paginile la latime de calculator si de telefon.

## Ce am invatat

Diferenta dintre `flex` si `float`, cum se face un meniu care se aseaza singur pe ecran mic si cum se organizeaza fisierele unui site.
