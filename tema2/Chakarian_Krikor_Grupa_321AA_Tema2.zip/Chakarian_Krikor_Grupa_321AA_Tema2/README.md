# Tema 2 - Site personal
**Chakarian Krikor, Grupa 321AA**

Pentru crearea site-ului am folosit HTML pentru structură și CSS pentru aspect. Toate cele patru pagini create folosesc același meniu cu logo și aceeași foaie de stil.
- `home.html` prezintă pe scurt educația, competențele și hobby-urile mele.
- `about.html` include informații despre mine și despre activitatea mea de voluntariat.
- `portofolio.html` afiseaza trei proiecte personale.
- `contact.html` conține datele de contact și un formular care deschide aplicația de email.

Foaia de stil se află în `CSS/styles.css`, in timp ce imaginile sunt în directorul `Images/`. Pentru meniu am folosit CSS Grid, iar pentru alinierea textului, a imaginilor și a elementelor din footer, Flexbox. Meniul se așază pe două rânduri si imaginile apar sub text, la lățimi de cel mult 600 px.

Pentru a vedea site-ul, deschideți `home.html` în browser.