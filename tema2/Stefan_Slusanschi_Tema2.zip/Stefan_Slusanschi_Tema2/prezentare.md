# Tema 2 - Personal website: descrierea implementării

**Autor:** Stefan Slusanschi, gemini(fisierul de explicatii)

## Structură
- `home.html` - pagina principală (prezentare, Educație, Competențe, Hobby)
- `pages/about.html`, `pages/portofolio.html`, `pages/contact.html`
- `css/style.css` - un singur fișier de stiluri, folosit de toate paginile
- `images/` - fotografia de profil și logo-ul (SVG)

Fișierele sunt organizate pe foldere după rol: pagini, stiluri, imagini.

## Cerințe de temă
- **Navigation bar** cu linkuri către toate paginile, în header, identică pe fiecare pagină.
- **Logo** în header (cip stilizat cu inițialele SS), cu link către pagina principală.
- **Footer** cu linkuri Facebook, Twitter, GitHub, email și copyright.
- **HTML și CSS nativ**, fără biblioteci sau framework-uri. Comentarii în ambele.

## Bune practici de design grafic
- **Contrast:** header și footer închise la culoare cu text alb; boxuri albe pe fundal deschis; accentul verde deschis spre galben apare doar la pagina curentă și la bordurile header/footer.
- **Aliniere:** conținutul stă într-un container de lățime maximă fixă, aliniat la stânga; elementele din grile au aceleași margini.
- **Proximitate:** elementele înrudite (titlu, perioadă, descriere) sunt în același box, iar distanțele dintre secțiuni sunt mai mari decât cele din interiorul cardurilor.
- **Repetiție:** aceleași culori (variabile CSS), același stil de box, același header și footer pe toate paginile.

## Bune practici UI
- **Arhitectura informației:** ierarhie clară h1, h2, h3; meniu simplu cu 4 intrări.
- **Information scent:** etichetele din meniu spun ce conține pagina, iar pagina curentă este evidențiată (`aria-current`).
- **Consistență:** aceleași componente (box, buton, etichete) în toate paginile.

## Responsive
- Meta tag `viewport` pe fiecare pagină.
- Grile cu `repeat(auto-fit, minmax(...))`, care trec automat de la 3 coloane la una.
- `@media (max-width: 700px)`: poza trece deasupra textului, meniul și footer-ul se aranjează pe verticală.
- Unități relative (`rem`, `clamp`) pentru text.

## Corectitudinea codului
- `<!DOCTYPE html>`, `lang="ro"`, tag-uri semantice (`header`, `nav`, `main`, `section`, `article`, `footer`).
- `alt` la imagini, `label` legat de fiecare câmp din formular, focus vizibil la tastatură.
- Indentare consecventă, selectori de clasă, variabile CSS pentru culori și dimensiuni.
